---
title: İlk Blog Yazım
date: 2025-01-01
image: /assets/uploads/sample.jpg
category: Genel
---

# Merhaba!

Bu blog artık:

✔ Modern tema  
✔ Kategoriler  
✔ Görsel desteği  
✔ Yorum sistemi  

hepsiyle birlikte çalışıyor!
